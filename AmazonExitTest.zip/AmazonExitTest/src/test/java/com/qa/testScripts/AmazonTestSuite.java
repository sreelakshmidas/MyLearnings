package com.qa.testScripts;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.amazonBase.AmazonBase;
import com.qa.pages.AddToCart;
import com.qa.pages.AmazonHomePage;
import com.qa.pages.SearchResult;
import com.qa.pages.SelectBook;
import com.qa.pages.ShoppingCart;
import com.qa.utilities.ReadExcel;


public class AmazonTestSuite extends AmazonBase
{
		AmazonHomePage home;
		SearchResult search;
		SelectBook select;
		AddToCart add;
		ShoppingCart shop;
		
		
	
		@Test(priority=1)
		public void searchItem() throws IOException 
		{
			home=new AmazonHomePage(driver);
			search=new SearchResult(driver);
			select= new SelectBook(driver);
			add=new AddToCart(driver);
			shop=new ShoppingCart (driver);
			
			
			
			String search_product=ReadExcel.getCellData(1, 0,System.getProperty("user.dir")+"\\src\\main\\resources\\AmazonSearch.xlsx",0);
			home.setSearchValue(search_product);
			home.clickSearch();
			
			String search_result=search.getSearchBook();
			Assert.assertEquals(search_result,"Books");
			search.clickPaperback();
			
			
			String book=select.getBookName();
			Assert.assertEquals(book,"Aatujeevitham (Malayalam Edition)");
			select.clickAddToCartButton();
			
			
			String addToCartPageText=add.cartText();
			Assert.assertEquals(addToCartPageText,"Added to Cart");
			add.clickGoToCartIcon();
			
			
			shop.clickDelete();
			String cartPageTextAfterDeletion=shop.cartTextAfterDeletion();
			Assert.assertEquals(cartPageTextAfterDeletion,"Subtotal (0 items):");
			
				
		}

	
}
