package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.amazonBase.AmazonBase;

public class SelectBook extends AmazonBase
{
	WebDriverWait wait;
	
	//xpath for book name
	@FindBy(id="productTitle")
	private WebElement book_name;
	
	//xpath for add to cart button
	@FindBy(id="add-to-cart-button")
	private WebElement add_to_cart_button;
	
	
	
	
	public SelectBook(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}

	
	
	
	
	public String getBookName()
	{
		String text=book_name.getText();
		return text;
	}
	
	public void clickAddToCartButton()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("add-to-cart-button")));
		add_to_cart_button.click();
	}
	
	
}
