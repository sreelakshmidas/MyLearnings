package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.amazonBase.AmazonBase;

public class ShoppingCart extends AmazonBase
{

	WebDriverWait wait;
	
	//xpath for delete button to removing the product from cart
	@FindBy(xpath="//input[@value='Delete']")
	private WebElement delete;
		
	
	//xpath for text after delete the product
	@FindBy(xpath="//div[@data-name='Subtotals']//child::span[1]")
	private WebElement delete_text;
	
	
	
	
	
	
	public ShoppingCart(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}

	
	public void clickDelete()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Delete']")));
		delete.click();
	}
	

	public String cartTextAfterDeletion()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-name='Subtotals']//child::span[1]")));
		String text=delete_text.getText();
		return text;
	}
	
	
	
}
