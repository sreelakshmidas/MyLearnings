package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.amazonBase.AmazonBase;

public class AddToCart extends AmazonBase
{

	WebDriverWait wait;
	
	//xpath for add to cart text
	@FindBy(xpath="//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']//child::span")
	private WebElement cart_page_text;
		
	//xpath for go to cart icon
	@FindBy(xpath="//span[@id='nav-cart-count']")
	private WebElement cart;
			
		
	
	
	
	public AddToCart(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}

	
	
	public String cartText()
	{
		String text=cart_page_text.getText();
		return text;
	}
	
	
	public void clickGoToCartIcon()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='nav-cart-count']")));
		cart.click();
	}
	
	
	
}
