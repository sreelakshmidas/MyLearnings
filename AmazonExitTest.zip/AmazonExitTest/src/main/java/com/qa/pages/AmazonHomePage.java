package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.amazonBase.AmazonBase;

public class AmazonHomePage extends AmazonBase
{
	
	WebDriverWait wait;
	
	//xpath for amazon products search button
	@FindBy(id="twotabsearchtextbox")
	private WebElement search_bar;
	
	//xpath for search icon
	@FindBy(id="nav-search-submit-button")
	private WebElement search_icon;
	
	
	
	
	
	public AmazonHomePage(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}
	
	
	

	
	public void setSearchValue(String value)
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("twotabsearchtextbox")));
		search_bar.click();
		search_bar.sendKeys(value);
		
	}
	
	public void clickSearch()
	{
		search_icon.click();
	}
	

	
}
