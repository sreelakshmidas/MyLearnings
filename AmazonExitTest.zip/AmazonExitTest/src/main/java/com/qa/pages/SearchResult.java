package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.amazonBase.AmazonBase;

public class SearchResult extends AmazonBase
{
	WebDriverWait wait;
	
	

	//xpath for search result
	@FindBy(xpath="//span[text()='Books']")
	private WebElement books_page;
	
	
	//xpath for paperback button
	@FindBy(xpath="//a[text()='Paperback']")
	private WebElement paperback;
	
	
	
	
	
	public SearchResult(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}
	
	
	
	
	public String getSearchBook()
	{
		String text=books_page.getText();
		return text;
	}
	
	public void clickPaperback()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Paperback']")));
		paperback.click();
	}
	
	
}
